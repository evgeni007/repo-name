<?php
namespace BootstrapPHP;

/**
 * Короткая запись для класcа иконки
 */
class I extends Icon {}