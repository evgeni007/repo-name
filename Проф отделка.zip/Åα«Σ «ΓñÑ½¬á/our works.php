<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Наши работы</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="styles.css">
</head>

<body>

    <body>
        <div class="d-flex flex-column flex-md-row align-items-center pb-3 mb-4 border-bottom">
            <a href="/" class="d-flex align-items-center text-dark text-decoration-none">
                <img class="slogan" src="image\clp1200410.jpg">
                <span class="fs-4">Декоративная отделка балкона 56</span>
            </a>

            <nav class="d-inline-flex mt-2 mt-md-0 ms-md-auto">
                <a class="me-3 py-2 text-dark text-decoration-none" href="index.php">Главная</a>
                <a class="me-3 py-2 text-dark text-decoration-none" href="contacts.php">Контакты</a>
                <a class="me-3 py-2 text-dark text-decoration-none" href="materials.php">Материалы</a>
                <a class="me-3 py-2 text-dark text-decoration-none" href="our works.php">Мои работы</a>
                <a class="py-2 text-dark text-decoration-none" href="design.php">Дизайн</a>
            </nav>
        </div>
    </body>

    <div class="card-deck">
        <div class="card">
            <img src="image\_Ko6nEmjVHXBcHp0VHDpbQFsxAn-jHNUZ_CRWQOYLcNVqeFnIKSwIdSnoI2TCiMR0QXgpB1HQJ6lA1KU8f9C-54W.jpg" class="card-img-top" alt="">
            <div class="card-body">
                <h5 class="card-title">Линолеум на пол</h5>
                <p class="card-text">от 200 р/м²</p>
                <p class="card-text"><small class="text-muted"><img src="image\Frame(1).png"></small></p>
            </div>
        </div>
        <div class="card">
            <img src="image\CSb00XZo2cyumiM6MgGV0UAuscmMmI5sj9Go9846uedGuFj5jUqazgK9hyEw9fr9hIkdGxfWDAGMJPmckOgbBIgo.jpg" class="card-img-top" alt="">
            <div class="card-body">
                <h5 class="card-title">Ламинат на пол</h5>
                <p class="card-text">от 300 руб/м²</p>
                <p class="card-text"><small class="text-muted"><img src="image\Frame(1).png"></small></p>
            </div>
        </div>
        <div class="card">
            <img src="image\8XH-kAT6JYFDR4T1Z6ZuIALcbfgKfgOCEsIRoazvDLfAgb3tDGKtlqYSMlQz5gWZYH0aSv-GoggLqLWdAmlY3RsL.jpg" class="card-img-top" alt="">
            <div class="card-body">
                <h5 class="card-title">Плитка на пол</h5>
                <p class="card-text">от 1 000 руб/м²</p>
                <p class="card-text"><small class="text-muted"><img src="image\Frame(1).png"></small></p>
            </div>
        </div>
        <div class="card">
            <img src="image\IMAGE (3).png" class="card-img-top" alt="">
            <div class="card-body">
                <h5 class="card-title">Кварцвинил на пол</h5>
                <p class="card-text">от 300 руб/м²</p>
                <p class="card-text"><small class="text-muted"><img src="image\Frame(1).png"></small></p>
            </div>
        </div>
    </div>
    <div class="card-deck">
        <div class="card">
            <img src="image\ieK1x_GFgjWQ7RbiqLOsVyi2pySE6DUmahrWZfX27bx5VK1n-_JBNBqcoauE3jrwWDNQai7prW1De5P4OAgNBl45.jpg" class="card-img-top" alt="">
            <div class="card-body">
                <h5 class="card-title">Отделка балкона панелями</br>
                    ПВХ (на стены и потолок)</h5>
                <p class="card-text">от 500 руб/м²</p>
                <p class="card-text"><small class="text-muted"><img src="image\Frame(1).png"></small></p>
            </div>
        </div>
        <div class="card">
            <img src="image\WqKnFW1tEoRi-9UrqlT8FwTISGS2z6mOLkoTnMOHF-agccyJUz7EM9QwmICjBnLiIL_uB7yvkoQjE2lhdFI0Eo5q.jpg" class="card-img-top" alt="">
            <div class="card-body">
                <h5 class="card-title">Штукатурные работы</h5>
                <p class="card-text">от 500 руб/м²</p>
                <p class="card-text"><small class="text-muted"><img src="image\Frame(1).png"></small></p>
            </div>
        </div>
        <div class="card">
            <img src="image\WqKnFW1tEoRi-9UrqlT8FwTISGS2z6mOLkoTnMOHF-agccyJUz7EM9QwmICjBnLiIL_uB7yvkoQjE2lhdFI0Eo5q.jpg" class="card-img-top" alt="">
            <div class="card-body">
                <h5 class="card-title">Шпаклевочные работы</h5>
                <p class="card-text">от 400 руб/м²</p>
                <p class="card-text"><small class="text-muted"><img src="image\Frame(1).png"></small></p>
            </div>
        </div>
        <div class="card">
            <img src="image\ZxCIioXK7Yo4LIzS9Mqzsn5zpk0-DVdBDuC9LYcHCChjC0pFkYrefwt39L6YD7BM8VXKj1Nme_I181QcVL7he5kO.jpg" class="card-img-top" alt="">
            <div class="card-body">
                <h5 class="card-title">Покрасочные работы</h5>
                <p class="card-text">от 100 руб/м²</p>
                <p class="card-text"><small class="text-muted"><img src="image\Frame(1).png"></small></p>
            </div>
        </div>
    </div>
    <div class="card-deck">
        <div class="card">
            <img src="image\mhy73f2t2LjRbQe3_7TOeJ2yOlDZkb9k0WenMDJYuUYdvRg60MNN2kLcH_b7RYo6cdR2Pf636Ve9bn2HrWYz-t31.jpg" class="card-img-top" alt="">
            <div class="card-body">
                <h5 class="card-title">Декоративный кирпич</h5>
                <p class="card-text">от 1 000 руб/м²</p>
                <p class="card-text"><small class="text-muted"><img src="image\Frame(1).png"></small></p>
            </div>
        </div>
        <div class="card">
            <img src="image\h31zxx0CPn9uf2yT36SAN2xpYHnUMuh7yujSHoq8whzqVNi5HJJsylVFf5FNTZBkLD9ozd_cXDGqNC8-oHUmR-bv.jpg" class="card-img-top" alt="">
            <div class="card-body">
                <h5 class="card-title">Установка тёплого пола</h5>
                <p class="card-text">от 5 000 руб. за услугу</p>
                <p class="card-text"><small class="text-muted"><img src="image\Frame(1).png"></small></p>
            </div>
        </div>
        <div class="card">
            <img src="image\QWOEbJ_Q_-WBGvlXWaImgUqM4isHAv3k66Czuv0UZY1EMbMamW3rzWNbOsXxKfAdJCiO2T4YYAewrHPZ-sfnAngP.jpg" class="card-img-top" alt="">
            <div class="card-body">
                <h5 class="card-title">Установка встраиваемого шкафа</h5>
                <p class="card-text">от 5 000 руб. за 1 шт.</p>
                <p class="card-text"><small class="text-muted"><img src="image\Frame(1).png"></small></p>
            </div>
        </div>
        <div class="card">
            <img src="image\kC9-c6OYi9RhAZwyyA5NK4LKH7OvSA-2Fp6_FIexHDhR6xjinyX0FXHQjeAjQPHpA8oLSY36Ov1zG0LDDbkRzB_G.jpg" class="card-img-top" alt="">
            <div class="card-body">
                <h5 class="card-title">Мотнатаж выключателей, разеток, точечьных светильников, бра</h5>
                <p class="card-text">от 300 руб.</p>
                <p class="card-text"><small class="text-muted"><img src="image\Frame(1).png"></small></p>
            </div>
        </div>
    </div>
    <div class="card-deck">
        <div class="card">
            <img src="image\PwP0iVUggRCBpArxvlp8ly4EQRNfxPCQHzSFDuCPqxnCixAH1ghnLNlu8j4w0ufFjPdWNFdWdfDcCTecN9oc2WCo.jpg" class="card-img-top" alt="">
            <div class="card-body">
                <h5 class="card-title">Утипление пенополистиролом</h5>
                <p class="card-text">от 350 руб/м²</p>
                <p class="card-text"><small class="text-muted"><img src="image\Frame(1).png"></small></p>
            </div>
        </div>
        <div class="card">
            <img src="image\zirKYRFzPx0laI-TjGsB1xaVV_W1nuZLMcRqDDmXg3ie4921KOLXK_eoOzJ7nCk9YAjjFyBPXiO2l9xQMfdN4gwy.jpg" class="card-img-top" alt="">
            <div class="card-body">
                <h5 class="card-title">Обшивка балкона гипсо картоном</br>
                    (на стены и потолок)</h5>
                <p class="card-text">от 1 000 руб/м²</p>
                <p class="card-text"><small class="text-muted"><img src="image\Frame(1).png"></small></p>
            </div>
        </div>
        <div class="card">
            <img src="image\Hc4OukpM7sr7ySN1CtCPDTONmdmMUSqSqy8IFinhe0HHNw1h047QfmJRB9HIxstWFAmJhThzpSjOF2iE0hpGPBJS.jpg" class="card-img-top" alt="">
            <div class="card-body">
                <h5 class="card-title">Обшивка лоджи и балкона</br>
                    деревянной вагонкой</br>
                    (на стены и потолок)</h5>
                <p class="card-text">от 1 000 руб/м²</p>
                <p class="card-text"><small class="text-muted"><img src="image\Frame(1).png"></small></p>
            </div>
        </div>
        <div class="card">
            <img src="image\XMsMSZlbcOVvCwMYodLLCIcX5rqkxfLsEN9489A2_9zU7GJ3wv4upbgYNKDmv2oQXn0Jx4S_TeGFKYwIdHh4Dz2Y.jpg" class="card-img-top" alt="">
            <div class="card-body">
                <h5 class="card-title">Обшивка панелями МДФ</br>
                    (на стены и потолок)</h5>
                <p class="card-text">от 700 руб/м²</p>
                <p class="card-text"><small class="text-muted"><img src="image\Frame(1).png"></small></p>
            </div>
        </div>
        <div class="card">
            <img src="image\G_7x1vJithjNiGiPdMI3ZoUdFX5Dft8MZl8M1w9U0LZBT3z3Txc8Iv1sRbQO4q1KW6QMXcpn-m526z48FKT0JwGg.jpg" class="card-img-top" alt="">
            <div class="card-body">
                <h5 class="card-title">Обшивка стен ламинатом</h5>
                <p class="card-text">от 1 200 р/м²</p>
                <p class="card-text"><small class="text-muted"><img src="image\Frame(1).png"></small></p>
            </div>
        </div>
    </div>

    <footer class="pt-4 my-md-5 pt-md-5 border-top">
        <div class="row">
            <div class="col-12 col-md">
                <img class="slogan" src="image\clp1200410.jpg">
                <span class="fs-4">Декоративная отделка балкона 56</span>
                <small class="d-block mb-3 text-muted"><br>
                    <p class="footer">Я начинаю применять декоративную отделку балкона и лоджей<br>применяя новые технологии и красата вашей мечты выплотиться в реальность.</p>
                </small>
            </div>
            <div class="col-6 col-md">
                <h5>Особености</h5>
                <ul class="list-unstyled text-small">
                    <li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Обо мне</a></li>
                    <li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Рекомендации</a></li>
                    <li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Условия обслуживания</a></li>
                    <li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Конфиденциальность</a></li>
                    <li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Связаться со мной</a></li>
                </ul>
            </div>
            <br>
            <div class="col-6 col-md">
                <h5>Контакты</h5><br>
                <ul class="list-unstyled text-small">
                    <li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Следите за мной в соцсетях</a></li><br>
                </ul>
                <a href="image\away.php"><img src="image\174883.png" style="width: 20px; height: 20px;"></a>
            </div>
        </div>
        <br>
        <div class="copiraite">
            Copyright © 2022 Все права защищены | Этот шаблон создан с помощью Colorlib
        </div>
    </footer>

</body>

</html>