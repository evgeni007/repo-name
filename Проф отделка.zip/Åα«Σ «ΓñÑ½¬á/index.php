<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Декоративная отделка балкона 56</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <div class="d-flex flex-column flex-md-row align-items-center pb-3 mb-4 border-bottom">
        <a href="/" class="d-flex align-items-center text-dark text-decoration-none">
            <img class="slogan" src="image\clp1200410.jpg">
            <span class="fs-4">Декоративная отделка балкона 56</span>
        </a>

        <nav class="d-inline-flex mt-2 mt-md-0 ms-md-auto">
            <a class="me-3 py-2 text-dark text-decoration-none" href="index.php">Главная</a>
            <a class="me-3 py-2 text-dark text-decoration-none" href="contacts.php">Контакты</a>
            <a class="me-3 py-2 text-dark text-decoration-none" href="materials.php">Материалы</a>
            <a class="me-3 py-2 text-dark text-decoration-none" href="our works.php">Мои работы</a>
            <a class="py-2 text-dark text-decoration-none" href="design.php">Дизайн</a>
        </nav>
    </div>

    <div class="block-img">
        <div class="block-text">
            <h1 class="text">Давайте создадим балкон вашей мечты</h1>
        </div>
        <img class="block-img" class="block-img" src="image\8de406c9546fa93b31b992687d8fab3c.jpg">
    </div>

    <div class="container-block-text">
        <h4 class="text-p">Наш мастер выполняет ремонт и отделку балконов, лоджий под ключ в Оренбурге.</br>
            На наши услуги действует гарантия 1 год.</br>
            Среди преимуществ компании удобный сервис, доступные цены, покупка материала с клиентом.</h4>
    </div>
    <br>
    <div class="container-text">
        <div>
            <h4 class="content-text">
                Что входит в отделку под ключ:</br>
                Демонтаж старой отделки</br>
                Подготовка стен и пола</br>
                Утепление</br>
                Отделочные работы</br>
                Электрика</br>
            </h4>
        </div>
        <img class="img-png" src="image\Frame.png"><br>
        <p class="phone">89538317160</p>
        <img class="img-1" src="image\IbN8R0uXYPbDZc8FjJ46S-0N_kKGWcehqhaXmkLRDHn5GNCKR28pCmkU8uBGiSzQB3hysGyv41EsiIDkJJyiU9nM.jpg">
    </div>

    <a href="calculator.php"><button class="calculator">Расчитать</button></a>
    <!-- <p id="result"></p>href="calculator.php" onclick="func()" -->

    <footer class="pt-4 my-md-5 pt-md-5 border-top">
        <div class="row">
            <div class="col-12 col-md">
                <img class="slogan" src="image\clp1200410.jpg">
                <span class="fs-4">Декоративная отделка балкона 56</span>
                <small class="d-block mb-3 text-muted"><br>
                    <p class="footer">Я начинаю применять декоративную отделку балкона и лоджей<br>применяя новые технологии и красата вашей мечты выплотиться в реальность.</p>
                </small>
            </div>
            <div class="col-6 col-md">
                <h5>Особености</h5>
                <ul class="list-unstyled text-small">
                    <li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Обо мне</a></li>
                    <li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Рекомендации</a></li>
                    <li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Условия обслуживания</a></li>
                    <li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Конфиденциальность</a></li>
                    <li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Связаться со мной</a></li>
                </ul>
            </div>
            <br>
            <div class="col-6 col-md">
                <h5>Контакты</h5><br>
                <ul class="list-unstyled text-small">
                    <li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Следите за мной в соцсетях</a></li><br>
                </ul>
                <a href="image\away.php"><img src="image\174883.png" style="width: 20px; height: 20px;"></a>
            </div>
        </div>
        <br>
        <div class="copiraite">
            Copyright © 2022 Все права защищены | Этот шаблон создан с помощью Colorlib
        </div>
    </footer>
    <br>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js" integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

</html>