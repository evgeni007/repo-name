<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Материалы</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <div class="d-flex flex-column flex-md-row align-items-center pb-3 mb-4 border-bottom">
        <a href="/" class="d-flex align-items-center text-dark text-decoration-none">
            <img class="slogan" src="image\clp1200410.jpg">
            <span class="fs-4">Декоративная отделка балкона 56</span>
        </a>

        <nav class="d-inline-flex mt-2 mt-md-0 ms-md-auto">
            <a class="me-3 py-2 text-dark text-decoration-none" href="index.php">Главная</a>
            <a class="me-3 py-2 text-dark text-decoration-none" href="contacts.php">Контакты</a>
            <a class="me-3 py-2 text-dark text-decoration-none" href="materials.php">Материалы</a>
            <a class="me-3 py-2 text-dark text-decoration-none" href="our works.php">Мои работы</a>
            <a class="py-2 text-dark text-decoration-none" href="design.php">Дизайн</a>
        </nav>
    </div>
</body>

<footer class="pt-4 my-md-5 pt-md-5 border-top">
    <div class="row">
        <div class="col-12 col-md">
            <img class="slogan" src="image\clp1200410.jpg">
            <span class="fs-4">Декоративная отделка балкона 56</span>
            <small class="d-block mb-3 text-muted"><br>
                <p class="footer">Я начинаю применять декоративную отделку балкона и лоджей<br>применяя новые технологии и красата вашей мечты выплотиться в реальность.</p>
            </small>
        </div>
        <div class="col-6 col-md">
            <h5>Особености</h5>
            <ul class="list-unstyled text-small">
                <li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Обо мне</a></li>
                <li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Рекомендации</a></li>
                <li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Условия обслуживания</a></li>
                <li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Конфиденциальность</a></li>
                <li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Связаться со мной</a></li>
            </ul>
        </div>
        <br>
        <div class="col-6 col-md">
            <h5>Контакты</h5><br>
            <ul class="list-unstyled text-small">
                <li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Следите за мной в соцсетях</a></li><br>
            </ul>
            <a href="image\away.php"><img src="image\174883.png" style="width: 20px; height: 20px;"></a>
        </div>
    </div>
    <br>
    <div class="copiraite">
        Copyright © 2022 Все права защищены | Этот шаблон создан с помощью Colorlib
    </div>
</footer>

</html>